import React, { useState, useRef, useEffect } from "react";
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { io } from "socket.io-client";

const socket = io("http://192.168.1.51:6008")


function App() {

  const [chat, setChat] = useState([
    {id: 1, text: "Hello! How can I help you?", sender: 'bot'}
  ])
  const [input, setInput] = useState('')
  const messageEndRef = useRef(null)

  const handleSend = () => {
    const sendMsg = {
      id: chat.length + 1,
      text: input.trim(),
      sender: 'user'
    }

    setChat([...chat, sendMsg])
    socket.emit('send_message', sendMsg)
    setInput("")

    // setTimeout(() => {
    //   setChat((prev) => {
    //     return [...prev, {
    //     id: input.length + 1,
    //     text: 'Sorry I am Static bot!',
    //     sender: 'bot'
    //   }]
    //   })
    // }, 1000)

  }

  const handleKeyDown = (e) => {
    if(e.key === 'Enter'){
      e.preventDefault()
      handleSend()
    }
  }

  useEffect(() => {
    socket.on('receive_message', (data) => {
      setTimeout(() => {
        setChat((prev) => [...prev, data])
      }, 1000)
    })


    return () => {
      socket.off('receive_message')
    }

  }, [])

  useEffect(() => {
    messageEndRef.current?.scrollIntoView({behavior: 'smooth'})
    console.log("useeffecttt")
  }, [chat])


  return (
    <>
      <div className="container">
        <div className="chat-container">
          <div className="header">
            <h1>Chat Application</h1>
          </div>
          <div className="chat-box">
            {
              chat.map( (each, idx) => (
                <div key={idx} className={each.sender === 'bot'? 'bot-message' : 'user-message'}>
                  {each.text}
                </div>
              ))
            }
            <div ref={messageEndRef}/>
          </div>
          <div className="chat-bottom">
            <textarea placeholder="Type a message..." rows={3} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => handleKeyDown(e)}></textarea>
            <button className="sendBtn" onClick={handleSend}>Send</button>
          </div>
        </div>
      </div>
    </>
  )
}

export default App
